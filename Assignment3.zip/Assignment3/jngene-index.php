<!DOCTYPE html>
<html>
	<head>
			<title> Jennifer's Page </title> 
</head>

<body>

<h2>About me</h2>
<p>I had an immense passion for technology and being digitally creative for a really long time. I became interested in website design from one day stumbling upon the HTML and CSS of the blog themes for most of my favorite Tumblr users that I used to follow. This was around when I was in 10th grade. At the time, I didn’t know that the code that I was looking at was HTML, CSS, and some JavaScript. They all looked like letters and numbers to me and didn’t have any particular meaning. I did mess around with the CSS of the blog sites unknowingly. Usually inputting various color codes and font choices and refreshing the page to see the changes happen immediately. Along with that kind of experience, I also created and designed a website for the IB students at my high school using WIX as the website builder. So, I still was not explicitly working with the code of the website just quite yet.</p>
		

		<h2> Now</h2>

		
		<p>It wasn’t until I got into university and took CSC 170 during my first year that I realized the importance of the code that I was messing with when changing the numbers and letters from the Tumblr blog themes. I was very interested in the class and was thoroughly excited to learn as much as I could while taking the course. I could also see the career path that I could follow if I were to gain more knowledge in the area of creating websites. But I soon realized that I wanted to do more. I realized the potential that the digital could have for my creativity. And that pretty much explains why I am now a Digital Media Studies major. It’s where I can get to show my skills and learn more about all things digital and to keep on doing my own kind of digital composition of turning the ideas that I have in my head into digital pieces.</p>
		
		<h2> Life in College </h2>

		<p>I managed to get accepted into a great university that I am still currently attending, called the University of Rochester in the state of New York. I was pursuing a Brain and Cognitive Sciences major with the pre-med track when I first started university (solely because of the decisions made by my parents) but I soon realized that I didn’t want to do any of that. I then thought about maybe pursuing a computer science major and then a neuroscience major and then lastly a psychology major. But I didn’t want to do any of those majors because I did not see myself having a career in the fields that those majors represented. Of course, I knew that what I majored in did not absolutely guarantee a certain career path for me, but I just did not see myself in those majors for my time being in the university.</p>
		


	</main>

	</html>

