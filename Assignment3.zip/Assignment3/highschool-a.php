<?php 
$currentPage = "Alyssa Nelson | High School Theatre";
include "inc/html-top-a.inc";
?>

	<?php include "inc/nav-a.inc"; ?>

	<main>
		<h2>High School Theatre</h2>

		<p>I then went full speed ahead and pursued theatre. I did not concern myself with going to stressful tryouts or the grueling conditioning practices. The way I played sports, there was always a ranking and everyone was always fighting to get to the top. It was exhausting. With theatre, I did not feel this pressure and felt more joy regardless of the size of the role I got. With my new found passion, I started doing more plays and musicals. I met some amazing people, and the course of my life changed. It all came full circle my senior year when I got the role of Ariel in our production of “The Little Mermaid.” It was an extremely rewarding process, and I would go back to that moment in a heartbeat.</p>

	</main>

	<?php include "inc/main-nav2.inc"; ?>
	<?php include "inc/footer.inc"; ?>