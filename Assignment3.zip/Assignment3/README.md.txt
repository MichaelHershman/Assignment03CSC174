
The three things these students had in common was what they decided to talk about for their websites. Each talked about life before college, life during college and things they are up to now. 

Ontology
- Students share their experience 

Taxonomy
- Life before college, 
- College life
- How are things now? 

The choreography
- Students share about themselves growing up then how they go into UofR
- Students will share what they have done during college
-Student will share what they are currently up to. 

Its in this order because there's a clear progression of life events





